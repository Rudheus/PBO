public class EnglishLanguage extends Language {
    public EnglishLanguage() {
        // Inisialisasi teks dalam bahasa Inggris
        this.setTitle("PT BANK RAHMAN ISKANDAR\n");
        this.setChooseLanguageText("SELECT LANGUAGE");
        this.setPinPrompt("ENTER PIN:");
        this.setErrorMessage("Incorrect PIN, try again!");
        this.setTransactionPrompt("Choose a Transaction");
    }
}
