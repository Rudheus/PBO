public class IndonesianLanguage extends Language {
    public IndonesianLanguage() {
        // Inisialisasi teks dalam bahasa Indonesia
        this.setTitle("PT BANK RAHMAN ISKANDAR");
        this.setChooseLanguageText("PILIH BAHASA");
        this.setPinPrompt("MASUKKAN PIN:");
        this.setErrorMessage("PIN salah, coba lagi!");
        this.setTransactionPrompt("Pilih Transaksi");
    }
}
