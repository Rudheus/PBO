import javax.swing.*;
import java.awt.*;

class MyFrame extends JFrame {
    private String currentLanguage;

    public MyFrame() {
        this.setTitle("ATM");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setSize(800, 600);
        this.setLocationRelativeTo(null);
        this.setVisible(true);

        ImageIcon img = new ImageIcon("D:\\2.Kuliah\\3.Semester 3\\TA_PBO\\atm.jpg");
        this.setIconImage(img.getImage());
        this.getContentPane().setBackground(Color.blue);

        // Tambahkan ini agar frame segera memuat ulang
        this.revalidate();
        this.repaint();
    }

    public void setCurrentLanguage(String language) {
        this.currentLanguage = language;
    }

    public String getCurrentLanguage() {
        return currentLanguage;
    }
}
