import javax.swing.*;
import java.awt.*;

class LanguagePanel extends BasePanel {
    private Language currentLanguage;

    public LanguagePanel(MyFrame frame, JPanel pinPanel) {
        super(frame);
        this.setLayout(new BorderLayout());
        this.setBackground(Color.blue);

        // Default ke bahasa Inggris
        currentLanguage = new EnglishLanguage();

        JLabel languageLabel = new JLabel(currentLanguage.getTitle() + "\n" + currentLanguage.getChooseLanguageText(), SwingConstants.CENTER);
        languageLabel.setForeground(Color.yellow);
        languageLabel.setFont(new Font("Arial", Font.BOLD, 20));

        JPanel buttonPanel = new JPanel(new GridBagLayout());
        buttonPanel.setBackground(Color.blue);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;
        gbc.gridy = 0;

        JButton englishButton = new JButton("English");
        JButton indonesianButton = new JButton("Bahasa Indonesia");

        englishButton.addActionListener(e -> {
            currentLanguage = new EnglishLanguage(); // Set bahasa Inggris
            frame.setCurrentLanguage("English");
            switchToPanel(pinPanel); // Gunakan metode yang diwarisi dari BasePanel
        });

        indonesianButton.addActionListener(e -> {
            currentLanguage = new IndonesianLanguage(); // Set bahasa Indonesia
            frame.setCurrentLanguage("Bahasa Indonesia");
            switchToPanel(pinPanel); // Gunakan metode yang diwarisi dari BasePanel
        });

        buttonPanel.add(englishButton, gbc);
        gbc.gridy++;
        buttonPanel.add(indonesianButton, gbc);

        this.add(languageLabel, BorderLayout.NORTH);
        this.add(buttonPanel, BorderLayout.CENTER);
    }
}
